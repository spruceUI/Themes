# PICO-8 by 369px

### Credits
- Author: 369px
- Font and Palette: Zep (Lexaloffle)
- Console Icons: found on kantOS, original icons: https://yspixel.jpn.org/icon/game/