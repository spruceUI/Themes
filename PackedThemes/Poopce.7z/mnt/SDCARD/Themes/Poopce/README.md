# `poopce` *by* `my butt`

Theme for spruce modded stock os


## Credits


**Fonts:** Merged Nunito Designed by Vernon Adams and wqy-microhei from Miyoo

**Icons:** By [Icons8](https://icons8.com/) - Forma

**Console icons:** Default OnionOS (libretro systematic) with additional from retroactive