# `Avocado` *by* `Sky_Walker AKA GamerChef`

Theme for spruce modded stock os


## Credits

**Font SmallLcd.ttf:** by myname5749

**Icons:** By [Icons8](https://icons8.com/) - Cute Outline. Edited and modified by Sky_Walker

**Console Icons:** By Retroarch with additions by Sky_Walker AKA GamerChef

**Super Game Boy Icon:** By rodrigoomuller

**App Icons:** By [Icons8](https://icons8.com/) - Cute Outline. Edited and modified by Sky_Walker

**Avocado Icons:** By Sky_Walker AKA GamerChef

**Pico8 Icon**:** By Sky_Walker AKA GamerChef

**change.wav File:** By KulthyCZ used in CleanOnionGB for Onion

**bgm.mp3 File:** By anars

