# `Cosy` *by* `KyleBing`

Theme for spruce modded stock os


## Credits

**Nunwen Font:** by tenlevels (merged Nunito by Vernon Adams and wqy-microhei from Miyoo)

**Icons:** by KyleBing

**Console icons:** by KyleBing

**Proofreading:** SundownerSport
